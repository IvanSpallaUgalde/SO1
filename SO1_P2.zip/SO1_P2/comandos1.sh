ls
date
file nivel3.c #muestra tipo
ps
hola
sleep 1

